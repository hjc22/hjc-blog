import React, {Component} from 'react';


export default class Order extends Component {
  render() {
    return (
      <div>订单</div>
    )
  }
}
