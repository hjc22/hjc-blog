import React, {Component} from 'react';
import cs from '../assets/css/article.css'

export default class ErrorPage extends Component {
  render() {
    return (
      <div className={cs.article}>error</div>
    )
  }
}
