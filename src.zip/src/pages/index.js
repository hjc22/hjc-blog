import Index from './start.jsx'
import Order from './order.jsx'
import Login from './login.jsx'
import Article from './article.jsx'
import ErrorPage from './error.jsx'
import Edit from './editArticle.jsx'
import MySetting from './mySetting'
import MessagePage from './message'
export {
  Index,
  Order,
  Login,
  Article,
  ErrorPage,
  Edit,
  MySetting,
  MessagePage
}
