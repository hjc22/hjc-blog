import Axios from 'axios'

const dateFilter = date => {
  if(!date) return ''

  return date.split('-').filter( (item,i) => i !== 0 )
}


const likeNumFilter = val => {
  if(!val) return 0
  if(val < 10000) return val
  let str = String(val),x = str.length - 4
  return str.substring(0,x) + 'w+'
}

const clss = cls => {
  return cls.join(' ')
}

const axios = (url,data = {},opts = {}) => {
   return new Promise((resolve,reject) => {
     let { method = 'post',load = 1 ,headers} = opts


     if(method === 'get'){
       let arr = []
       for(let i in data){
         arr.push(i+'='+data[i])
       }
       url = arr.length?url+'?'+arr.join('&'):url

       data = {}
     }
     Axios({method,url,data,headers}).then( res => {
       let dt = res.data
       if(dt.code!==1) reject(dt.error || '请求错误')

       resolve(dt.data)
     })
     .catch(err => {
       console.log(err)

       reject(err || '请求错误')
     })
   })

}

const toTop = (top = 0) => document.body.scrollTop = document.documentElement.scrollTop = top

export {
  dateFilter,
  likeNumFilter,
  axios,
  clss,
  toTop
}
