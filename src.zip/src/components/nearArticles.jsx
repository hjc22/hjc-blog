import React, {Component} from 'react';
// import { Row, Col } from 'antd';

import { observer } from 'mobx-react';
import { nearArticlesStore } from '../stores'
import cs from '../assets/css/nearArticle.css'
import { ModuleTitle } from '../components'

@observer
class NearArticles extends Component {
   componentDidMount(){
      nearArticlesStore.init()
   }

   render(){
     return (
       <div className={cs.hotArticles}>
          <ModuleTitle title="近期文章" />
          <ul className={cs.artList}>
            { nearArticlesStore.list.map( (item,i) => Item(item,i))}
          </ul>
       </div>
     )
   }
}


const Item = (props,i) => (
  <li className={cs.artItem} key={i}>
    <div className={cs.itemRight}>
      <span className={cs.artName} title={props.articleTitle}>{props.articleTitle}</span>
      <span className={cs.artHot}>{props.date}</span>
    </div>

  </li>
)



export default NearArticles
