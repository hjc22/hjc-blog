import React, {Component} from 'react';

import cs from '../assets/css/modal.css'



class Modal extends Component {

   render(){
     return (
       <div className={cs.modalBg}>

       </div>
     )
   }
}



export default Modal
