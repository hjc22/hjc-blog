import React, {Component} from 'react';
// import { Row, Col } from 'antd';

import { observer } from 'mobx-react';
import { hotArticlesStore } from '../stores'
import cs from '../assets/css/hotArticles.css'
import { ModuleTitle } from '../components'

@observer
class HotArticles extends Component {
   componentDidMount(){
      hotArticlesStore.init()
   }

   render(){
     return (
       <div className={cs.hotArticles}>
          <ModuleTitle title="热门文章" />
          <ul className={cs.artList}>
            { hotArticlesStore.list.map( (item,i) => Item(item,i))}
          </ul>
       </div>
     )
   }
}


const Item = (props,i) => (
  <li className={cs.artItem} key={i}>
    <span className={cs.itemIndex}>{i+1}</span>
    <div className={cs.itemRight}>
      <span className={cs.artName} title={props.articleTitle}>{props.articleTitle}</span>
      <span className={cs.artHot}>{props.likeNum}</span>
    </div>

  </li>
)



export default HotArticles
