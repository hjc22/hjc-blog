import React from 'react';

export default props => (
  <h4 className='globalTitle'>{props.title}</h4>
)



// export {moduleTitle}
