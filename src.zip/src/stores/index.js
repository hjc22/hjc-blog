import {observable, action, computed, runInAction} from 'mobx'

import { axios,toTop } from '../utils'
import { Message } from 'antd'
import timeStorage from 'time-localstorage'
import browserHistory from 'react-router';

import mySetting from './mySetting'


console.log(browserHistory)

class CommStore {
  @observable isLogin = false
  @observable isLogingModal = false

  @observable isRegister = false

  @observable userName = ''

  @observable myUserInfo = ''

  @observable password = ''

  @observable email = ''

  @action setLoginModal(val = true){
    this.isLogingModal = val
  }

  @computed get userInfo(){
    if(this.myUserInfo) return this.myUserInfo

    const userInfo = timeStorage.get('userInfo')

    if(userInfo){
      this.myUserInfo = userInfo
      this.isLogin = true
      return userInfo
    }
    else {
      this.isLogin = false
      return false
    }
  }

  @action setRegister(val = true){
    this.isRegister = val
  }

  @action setText(name,value){
    this[name] = value

  }
  @action logout(){

    axios('/api/logout',{}).then( dt => {
      runInAction(() => {
        timeStorage.remove('userInfo')

        this.isLogin = false

        this.myUserInfo = {}

      })
    })


  }

  @action getLogin(){
    return new Promise((resolve,reject) => {
      const { userName,password } = this

      if(!checkInput(0,userName,password)) return reject()


      axios('/api/login',{userName,password},{method:'post'}).then( dt => {

        timeStorage.set('userInfo',dt,3 * 3600 * 24)

        runInAction(() => {
           this.isLogin = true
           this.isLogingModal = false

           this.myUserInfo = dt
        })
      })
    })
  }

  @action getRegister(){
    return new Promise((resolve,reject) => {
      const { userName,password,email } = this

      if(!checkInput(1,userName,password,email)) return reject()



      axios('/api/register',{userName,password,email},{method:'post'}).then( dt => {

        timeStorage.set('userInfo',dt,3 * 3600 * 24)

        runInAction(() => {
           this.isLogin = true
           this.isLogingModal = false

           this.myUserInfo = dt
        })
      })
    })
  }
}

function checkInput(type,userName,password,email){
  let pwdreg=/^[a-zA-Z]\w{5,17}$/,namereg=/.{3,10}/,emailReg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
  if(!userName) return Message.warning('没输入用户名哦(๑´ڡ`๑)'),0
  if(!namereg.test(userName)) return Message.warning('用户名需要3-10个字符(๑´ڡ`๑)'),0
  if(!password) return Message.warning('没输入密码哦(๑´ڡ`๑)'),0
  if(!pwdreg.test(password)) return Message.warning('密码需要首字母，6-18个字符(๑´ڡ`๑)'),0

  if(type){
    if(!email) return Message.warning('没输入邮箱哦(๑´ڡ`๑)'),0
    if(!emailReg.test(email)) return Message.warning('邮箱不规范(๑´ڡ`๑)'),0
  }


  return 1
}

class NavMenuStore {
  @observable menus = [
    {name:'首页'},
    {name:'标签'},
    {name:'关于'},
    {name:'动态'},
    {name:'留言板'}
  ]

  @observable status = false
  @observable mMenuStatus = false


  @action open(){
    this.status = !this.status
  }

  @action mobileOpen(){
    this.mMenuStatus = !this.mMenuStatus
  }
}

class MusicPlayerStore {
  @observable songs = [
    {
      id:'28406753',
      name:'义气',
      album:{
        picUrl:'http://p1.music.126.net/Nl0RTYfKGynZsS89SKpjdQ==/3385396303311359.jpg'
      },
      artists:[
        { name:'黄海波' },{ name:'王雷' },{ name:'李健' },{ name:'张宁江' },
      ]
    }
  ]

  @observable list = []

  @observable playStatus = true
  @observable muted = true

  @observable activeIndex = 0

  @observable audio = {}

  @computed get activeSong (){
    return this.songs[this.activeIndex] || {}
  }

  @action setAudio (audio){
    this.audio = audio
  }
  @action play(){

    this.playStatus = !this.playStatus

    if(this.playStatus) this.audio.play()
    else this.audio.pause()
  }
  @action stop(){
    this.playStatus = false
  }
  @action next(){
    let len = this.songs.length


    if(this.activeIndex === len - 1 ) this.activeIndex = 0
    else this.activeIndex++

    setTimeout(() => this.audio.play(),this.playStatus = true)

  }
  @action prev(audio){
    let len = this.songs.length
    // this.playStatus = true
    if(this.activeIndex === 0 ) this.activeIndex = len - 1
    else this.activeIndex--
    setTimeout(() => this.audio.play(),this.playStatus = true)

  }
  @action pickSong(i,audio){
    let index = Number(i)
    if(this.activeIndex === index) return
    this.playStatus = true
    this.activeIndex = index
    setTimeout(() => this.audio.play())
  }
  @action getMute(audio){

    this.muted = !this.muted
    this.audio.muted = !this.muted
  }

  @action getList(){
    axios('/api/musics',{},{ method:'get' }).then( dt => {
      runInAction( () => {
        this.songs = this.songs.concat(dt)
      })
    })

  }
}

class NearCommentsStore {
  @observable comments = []

  @action open(){
    this.status = !this.status
  }

  @action init(){
    axios('/api/nearComments',{},{method:'get'}).then( dt => {

      runInAction(() => {
        this.comments = dt
      })
    })
  }
}

class HotArticlesStore {
  @observable list = []

  @observable status = false


  @action open(){
    this.status = !this.status
  }

  @action init(){
    axios('/api/hotArticles',{},{method:'get'}).then( dt => {
      this.list = dt
    })
  }
}
class NearArticlesStore {
  @observable list = []

  @observable status = false


  @action open(){
    this.status = !this.status
  }

  @action init(){
    axios('/api/nearArticles',{},{method:'get'}).then( dt => {
      this.list = dt
    })
  }
}

class CountStore {
  @observable list = []

  @action init(){
    axios('/api/counts',{},{method:'get'}).then( dt => {
      runInAction(() => {
        this.list = dt
      })
    })
  }
}

class SwiperStore {
  @observable list = [
    {imgUrl:'http://p1.music.126.net/SWDOrvO3f6L8Q1xGPTbb6w==/109951163102543599.jpg?param=700y260',title:'',id:'',type:''},
    {imgUrl:'http://p1.music.126.net/SWDOrvO3f6L8Q1xGPTbb6w==/109951163102543599.jpg?param=700y260',title:'',id:'',type:''},
    {imgUrl:'http://p1.music.126.net/SWDOrvO3f6L8Q1xGPTbb6w==/109951163102543599.jpg?param=700y260',title:'',id:'',type:''},

  ]
}

class ArticleListStore {
  @observable list = []

  @observable nowPage = 0
  @observable totalPage = 4
  @action getPageList(page = 1){
    this.nowPage = page
    axios('/api/queryArticleList',{page},{method:'get'}).then( dt => {

      runInAction(() => {
        this.totalPage = dt.allCount
        this.list = dt.list
        // toTop()
      })
    })
  }
}

class EditStore {
  @observable artPhotoStatus = false
  @observable isInputLink = false

  @observable titleImgloading = false

  @observable preloadShow = false

  @observable articleText = ''

  @observable articleTitle = ''

  @observable tagId = 1

  @observable titleImg = ''

  @action setArtPhotoStatus(val){


    this.artPhotoStatus = !!val
  }

  @action setPreloadShow(val = true){


    this.preloadShow = val
  }
  @action edit(text){
    this.articleText = text
  }

  @action setTitle(val){
    this.articleTitle = val
  }
  @action setTagId(id){
    this.tagId = id
  }
  @action setInputLink(val = true){
    this.isInputLink = val
  }

  @action setTitleImg(val){
    this.titleImg = val
  }
  @action clearAll(){
    this.articleText = ''
    this.titleImg = ''
    this.articleTitle = ''
    this.tagId = 1
  }
  @action editArticle(input){

    const { articleText,titleImg,articleTitle,tagId} = this

    if(!articleTitle) return Message.warning('没有输入文章标题哦！(๑´ڡ`๑) ')
    if(!articleText) return Message.warning('没有输入文章内容哦！(๑´ڡ`๑) ')

    axios('/api/editArticle',{articleText,titleImg,articleTitle,tagId} ).then( dt => {
       runInAction(() => {
           this.clearAll()
       })
       Message.success('文章发布成功！(｡◕‿◕｡)')

       input.value = null
    })
  }
  @action upload(file,input){
    let form = new FormData()

    form.append('img',file)

    this.titleImgloading = true

    axios('/api/uploadPhoto',form,{ headers:{'Content-Type':'multipart/form-data'} } ).then( dt => {
       runInAction(() => {
         this.titleImg = dt
         this.titleImgloading = false


       })

       input.value = null
    })
    .catch( err => {

      runInAction(() => {
        this.titleImgloading = false
      })
      input.value = null
      Message.error(err)
    })
  }
}

class ArticleStore {
  @observable infos = {}


  @observable commentText = ''

  @observable payStatus = false

  @observable activeCommentId = ''

  @observable sender = {}

  @action open(){
    this.payStatus = !this.payStatus
  }

  @action setCommentId(id){
    this.activeCommentId = id
  }

  @action init(id){
    axios('/api/queryArticle',{articleId:id},{method:'get'}).then( dt => {
       this.infos = dt
    })
  }
  @action setSender(info){
    this.sender = info
  }
  @action setText(text){

    this.commentText = text
  }
  @action setComment(input,type){
    let { commentText,infos,activeCommentId,sender } = this,{ articleId } = infos
    if(!commentText) return Message.warning('总要打点字吧(๑´ڡ`๑)')

    let data = { articleId,commentText }
    if(type){

      data.commentId = type?type:activeCommentId
      data.senderId = sender.userId
      data.senderName = sender.userName
    }

    axios('/api/setComment',data).then( dt => {
      runInAction(() => {

        if(!type) this.infos.commentsList.push(dt)

        else {
          let index = this.infos.commentsList.findIndex(item => item.commentId === type)
          if(index!==-1) this.infos.commentsList[index].replyList.push(dt)

        }
        this.commentText = ''
        input.value = null

        this.activeCommentId = ''
      })
    })
  }

}
export const navMenuStore = new NavMenuStore()
export const musicPlayerStore = new MusicPlayerStore()
export const nearCommentsStore = new NearCommentsStore()
export const hotArticlesStore = new HotArticlesStore()
export const countStore = new CountStore()
export const articleListStore = new ArticleListStore()
export const swiperStore = new SwiperStore()
export const nearArticlesStore = new NearArticlesStore()
export const articleStore = new ArticleStore()
export const editStore = new EditStore()

export const commonStore = new CommStore()
export const mySettingStore = mySetting
